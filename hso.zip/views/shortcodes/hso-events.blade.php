<!-- Event section -->
<div id="event-section">
	<div class="grid">
		<div class="grid-sm-12">
			<h1 class="title">Sök Biljetter</h1>
		</div>
	</div>
	<div class="grid">
		<div class="grid-sm-12">
			<div class="view-selector">
				<ul>
					<li class="active"><a class="layout" href="javascript:;" data-layout="grid-layout"><i class="fa fa-th" aria-hidden="true"></i> Grid </a></li>
					<li><a class="layout" href="javascript:;" data-layout="list"><i class="fa fa-bars" aria-hidden="true"></i> Lista</a></li>
					<li><span class="detail"><span class="line"></span>Telefon biljettkassa: 042-10 42 80</span></li>
				</ul>
			</div>
		</div>
	</div>
	<div id="filters">
		<ul>
			<li class="active"><a href="javascript:void(0)">Alla datum</a></li>
			<li><a href="javascript:void(0)" data-filter="jan">Januari</a></li>
			<li><a href="javascript:void(0)" data-filter="feb">Februari</a></li>
			<li><a href="javascript:void(0)" data-filter="mar">Mars</a></li>
			<li><a href="javascript:void(0)" data-filter="apr">April</a></li>
			<li><a href="javascript:void(0)" data-filter="may">Maj</a></li>
			<li><a href="javascript:void(0)" data-filter="jun">Juni</a></li>
			<li><a href="javascript:void(0)" data-filter="jul">Juli</a></li>
			<li><a href="javascript:void(0)" data-filter="aug">Augusti</a></li>
			<li><a href="javascript:void(0)" data-filter="sep">September</a></li>
			<li><a href="javascript:void(0)" data-filter="oct">Oktober</a></li>
			<li><a href="javascript:void(0)" data-filter="nov">November</a></li>
			<li><a href="javascript:void(0)" data-filter="dec">December</a></li>
		</ul>
		<p class="note">
			<span class="star">(*)</span> Standardval, fyll i de val du vill söka på
		</p>
	</div>

	<?php
		$event = new \HSOEventManager\Event();
		$events = $event->get_events();
	?>

	@if($events)
	<div class="grid">
		<div class="grid-sm-12">

			<div id="items" class="grid-layout">
				@foreach ($events as $event)

					{{-- # Set featured image # --}}
					<?php $featured = ""; ?>
					@if($event['featured'])
						<?php $featured = $event['featured'][0] ?>
					@endif

					<?php
						// retrive all moths tags for an item
						$date_tags = array();
						$date_tags_string = "";
						if(isset($event['transtickets'])){
							foreach ($event['transtickets'] as $transticket) {
								$date_tags[] = strtolower(date('M',strtotime($transticket['eventdate'])));
							}

							// remove duplicate months
							$date_tags = array_unique($date_tags);

							$date_tags_string = implode(" ",$date_tags);
						}

					?>

					<div class="item {{ $date_tags_string }}" style="{{ $featured != "" ? 'background-image:url('.$featured.')' : "" }}">
						<div class="item-content">
							<div class="top">
								@if(isset($event['transtickets']))
									<div class="date-time">
										@foreach($event['transtickets'] as $transticket)
											<p>
												<i class="fa fa-clock-o" aria-hidden="true"></i>
												<span>{{ date('H.i',strtotime($transticket['eventdate'])) }}</span> TDR <span>{{ date('d M',strtotime($transticket['eventdate'])) }}</span>
											</p>
										@endforeach
									</div>
								@endif
								<div class="tag"><span>AW</span></div>
							</div>
							<div class="bottom">
								<h1 class="event-title">{{ $event['title'] }}</h1>
								<ul class="buttons">
									<li class="first"><a href="{{ $event['buy_event_ticket_link'] != "" ? $event['buy_event_ticket_link'] : '#'  }}" target="_blank">Köp</a></li>
									<li class="second"><a href="{{ $event['link'] }}">Läs mer</a></li>
								</ul>
							</div>
						</div>
					</div>
				@endforeach
			</div> <!-- Grid itmes -->

			<div id="items" class="list" style="display: none">
				@foreach ($events as $event)
				<?php
					// retrive all moths tags for an item
					$date_tags = array();
					$date_tags_string = "";
					if(isset($event['transtickets'])){
						foreach ($event['transtickets'] as $transticket) {
							$date_tags[] = strtolower(date('M',strtotime($transticket['eventdate'])));
						}

						// remove duplicate months
						$date_tags = array_unique($date_tags);

						$date_tags_string = implode(" ",$date_tags);
					}

				?>
				<div class="item {{ $date_tags_string }}">
					<div class="item-content">
						@if($event['featured'])
						<img src="{{ $event['featured'][0] }}">
						@endif
						<div class="item-meta">
							<h1 class="event-title">{{ $event['title'] }}</h1>
							@if(isset($event['transtickets']))
								<div class="date-time">
									@foreach($event['transtickets'] as $transticket)
										<p>
											<i class="fa fa-clock-o" aria-hidden="true"></i>
											<span>{{ date('H.i',strtotime($transticket['eventdate'])) }}</span> TDR <span>{{ date('d M',strtotime($transticket['eventdate'])) }}</span>
										</p>
									@endforeach
								</div>
							@endif
						</div>
						<ul class="buttons">
							<li class="first"><a href="#">Köp</a></li>
							<li class="second"><a href="{{ $event['link'] }}">Läs mer</a></li>
						</ul>
						<div class="clear"></div>
					</div>
				</div>
				@endforeach
			</div> <!-- List itmes -->

		</div>
	</div>
	@else
		<h3>No events found</h3>
	@endif

	<div id="view-more">
		<a href="#">Visa fler</a>
	</div>
</div>
