<div id="carousal">
    <h1 class="carousal-title">Hetast just nu</h1>
    <div class="carousal-container" style="background-image: url('{{ get_stylesheet_directory_uri() ."/assets/dist/images"  }}/whatsup-blog.png')">						<div class="content">
            <div class="top">
										<span class="date">
											<i class="fa fa-clock-o" aria-hidden="true"></i>
											<span class="time">19.00</span> TOR <span class="date-string">4 NOV</span>
										</span>
            </div>
            <div class="bottom">
                <h1 class="title">Öppningskonsert</h1>
                <p class="description">Forage polaroid kinfolk dreamcatc tote bag, pop-up selfies master cl synth direct trade godard...</p>
            </div>
        </div>
    </div>
</div>