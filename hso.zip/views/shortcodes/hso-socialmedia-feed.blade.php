<div id="social">
    <h1 class="social-title">Sagt i sociala medier</h1>
    <div class="social-container">
        <h1 class="social-container-title">
            <span>Facebook</span>
            <img src="{{ get_stylesheet_directory_uri() ."/assets/dist/images"  }}/social-fb.png">
            <div class="clear"></div>
        </h1>
        <p class="description">
            I dag klockan 16.00 öppnar vi
            dörrarna till säsongens biljettsläpp
            på Konserthuset!<br><br>

            Under dagen erbjuder vi 50
            kronors rabatt på ordinarie
            biljettpris. Rabatten gäller i dag kl 16.00-20.00 vid direktköp
            i vår biljettkassa och på
            http://www.helsingborgs...
        </p>
        <a class="link" href="javascript:void(0)">Gå till facebook</a>
    </div>
</div>