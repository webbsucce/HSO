<div id="blog">
    <h1 class="blog-title">Chefens blogg</h1>
    <div class="blog-content">
        <h1 class="blog-content-title">Helvetica stumptown etsy</h1>
        <span class="blog-content-date">Publicerat: <span>2016-08-31</span></span>
        <p class="blog-content-detail">Forage polaroid kinfolk dreamcatc tote bag, pop-up selfies master cl synth direct trade godard. Farm-to-table hammock YOLO skateboard, salvia 90's yr +1 cred retro chartreuse polaroid....</p>
        <div class="blog-content-author">
            <div class="blog-content-author-image" style="background-image:url('{{ get_stylesheet_directory_uri() ."/assets/dist/images"  }}/blog-author.png')"></div>
            <h1 class="blog-content-author-title">Fredrik Österling</h1>
            <h2 class="blog-content-author-subtitle">Konserthuschef</h2>
            <div class="clearfix"></div>
        </div>
    </div>
</div>