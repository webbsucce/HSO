<div id="header">
    @include('partials.header.search-bar')
    <div class="container">
        <div class="logo-container">
            <a href="{{ home_url() }}">
                {!! municipio_get_logotype(get_field('header_logotype', 'option'), get_field('logotype_tooltip', 'option'), true, get_field('header_tagline_enable', 'option')) !!}
            </a>
        </div>
        <div class="menu-container">
            {!!
                wp_nav_menu(array(
                    'walker' => new QuickMenuWalker(),
                    'theme_location' => 'quick-menu',
                    'menu' => 'ul',
                    'menu_class' => 'quick-menu',
                    'menu_id' => 'menu',
                    'container' => false
                ))
            !!}
            <ul id="quick-menu-buttons">
                <li><a href="#translate" class="translate-icon-btn" aria-label="translate"><i class="fa fa-globe"></i></a></li>
                <li><a class="btn-search" href="javascript:void(0)"  data-tooltip="Search"><i class="fa fa-search"></i></a></li>
            </ul>
        </div>
        <div class="clearfix"></div>
    </div>
</div>

{{-- # Fixed header menu after scroll # --}}
<div id="header-fixed">
    <div class="container">
        <div class="menu-container">
            {!!
                wp_nav_menu(array(
                    'walker' => new QuickMenuWalker(),
                    'theme_location' => 'quick-menu',
                    'menu' => 'ul',
                    'menu_class' => 'quick-menu',
                    'menu_id' => 'menu',
                    'container' => false
                ))
            !!}
            <ul id="quick-menu-buttons">
                <li><a href="#translate" class="translate-icon-btn" aria-label="translate"><i class="fa fa-globe"></i></a></li>
                <li><a class="btn-search" href="javascript:void(0)"  data-tooltip="Search"><i class="fa fa-search"></i></a></li>
            </ul>
        </div>
        <div class="clearfix"></div>
    </div>
</div>

<div id="desktop-menu">
    <button class="btn-close"><i class="fa fa-close"></i></button>
    <div class="container">

        <div class="logo">
            {!! municipio_get_logotype(get_field('header_logotype', 'option'), get_field('logotype_tooltip', 'option'), true, get_field('header_tagline_enable', 'option')) !!}
        </div>

        <!-- Search box for general menu open -->
        <div class="grid">
            <div class="grid-sm-4">
                <form class="search" method="get" action="/">
                   <label for="search-keyword" class="sr-only">Sök på Helsingborg.se</label>
                   <div class="input-group input-group-lg">
                       <input id="search-keyword" autocomplete="off" class="form-control form-control-lg" type="search" name="s" placeholder="Search cupcakes">
                       <span class="input-group-addon-btn">
                           <input type="submit" class="btn btn-primary btn-lg" value="Search">
                       </span>
                   </div>
                </form>
            </div>
        </div>
        

        <!-- Empty mobile menu container to append mobile menu when its generated -->
        <div id="mobile-menu-container"></div>
        <div class="mobile-menu">
            {!!
                wp_nav_menu(
                    array (
                        'theme_location'  => 'full-menu',
                        'depth' => 3,
                    )
                )
            !!}
        </div>
        <div class="desktop-menu">
            {!!
                wp_nav_menu(
                    array (
                        'theme_location'  => 'full-menu',
                        'walker' => new FullMenuWalker(),
                        'depth' => 3,
                        'container' => 'div',
                        'container_class' => 'footer-menu',
                        'menu' => 'div',
                        'menu_class' => 'grid'
                    )
                )
            !!}
        </div>
        <div class="desktop-menu-line">
            <p>© 2016 · Helsingborg Arena &amp; Scen Ab · xxxxxx xxxx xx · xxx xxx xx</p>
        </div>
    </div>
</div>
@include('partials.header.translate')