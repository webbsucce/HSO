<header class="post-header">
    <h1><a href="{{ the_permalink() }}">{{ the_title() }}</a></h1>

    @include('partials.blog.post-info')
</header>
