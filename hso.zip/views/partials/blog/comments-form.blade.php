{!!
    comment_form(array(
        'class_submit' => 'btn btn-primary'
    ))
!!}
