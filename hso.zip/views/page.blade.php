@extends('templates.master')

@section('content')

<?php
    $header_image_style = "style=background-color:#7492a5";
    // set fatured image
    if(has_post_thumbnail()){
        $image = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' );
        if($image){
            $header_image_style = "style=background-image:url(".$image[0].")";
        }

    }

    // get title color
    $color = "#000";
    if(get_field('hso_page_settings_text_color')){
        $color = get_field('hso_page_settings_text_color');
    }

    // get subtitle
    $subtitle = "";
    if(get_field('hso_page_settings_subtitle')){
        $subtitle = get_field('hso_page_settings_subtitle');
    }

    // get gradient
    $gradient = false;
    if(get_field('hso_page_settings_gradient')){
        $gradient = (get_field('hso_page_settings_gradient') == "on" ? true : false);
    }
?>

<div id="header-image" {{ $header_image_style }} class="{{ $gradient ? 'shadow' : '' }}">
    <div class="container">
        <div class="grid">
            <div class="grid-sm-12 col">
                <div class="bottom">
                    <h1 class="title" style="color: {{ $color  }} !important">{{ get_the_title() }}</h1>
                    @if($subtitle)
                        <h3 class="sub-title" style="color: {{ $color  }} !important">{{ $subtitle }}</h3>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>

<div class="container main-container">

    @include('partials.breadcrumbs')
    
    <div class="grid {{ (wp_get_post_parent_id(get_the_id()) != 0) ? 'no-margin-top' : '' }}">
        @include('partials.sidebar-left')

        <div class="{{ $contentGridSize }} grid-print-12" id="readspeaker-read">

            @if (is_active_sidebar('content-area-top'))
                <div class="grid sidebar-content-area sidebar-content-area-top">
                    <?php dynamic_sidebar('content-area-top'); ?>
                </div>
            @endif

            @while(have_posts())
                {!! the_post() !!}
                @include('partials.article')
            @endwhile

            @if (is_active_sidebar('content-area'))
                <div class="grid sidebar-content-area sidebar-content-area-bottom">
                    <?php dynamic_sidebar('content-area'); ?>
                </div>
            @endif

            @include('partials.page-footer')
        </div>


        @include('partials.sidebar-right')
    </div>
</div>

@stop