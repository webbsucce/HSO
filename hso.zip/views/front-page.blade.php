@extends('templates.master')

@section('startboxes')
    <div id="start-boxes">
        {{-- # First box # --}}
        <div class="grid single-start-box-item">
            <div class="grid-sm-8">
                @if(get_field('image_1','option') != "")
                    <?php
                    $image = wp_get_attachment_image_src(get_field('image_1','option'),'full');
                    ?>
                    <div class="image" style="background-image: url('{{  $image[0] }}');"></div>
                @endif
            </div>
            <div class="grid-sm-4">
                <div class="content">
                    <h3 class="subtitle">{{ get_field('subtitle_1','option')  }}</h3>
                    <h1 class="title">{{ get_field('title_1','option')  }}</h1>
                    <a class="link" href="{{ get_field('link_1','option') ?: "#"  }}">Läs mer</a>
                </div>
            </div>
        </div>

        {{-- # Second box # --}}
        <div class="grid single-start-box-item">
            <div class="grid-sm-4">
                <div class="content">
                    <h3 class="subtitle">{{ get_field('subtitle_2','option')  }}</h3>
                    <h1 class="title">{{ get_field('title_2','option')  }}</h1>
                    <a class="link" href="{{ get_field('link_2','option') ?: "#"  }}">Läs mer</a>
                </div>
            </div>
            <div class="grid-sm-8">
                @if(get_field('image_2','option') != "")
                    <?php
                        $image = wp_get_attachment_image_src(get_field('image_2','option'),'full');
                    ?>
                    <div class="image" style="background-image: url('{{  $image[0] }}');"></div>
                @endif
            </div>
        </div>

        {{-- # Third box # --}}
        <div class="grid single-start-box-item">
            <div class="grid-sm-8">
                @if(get_field('image_3','option') != "")
                    <?php
                    $image = wp_get_attachment_image_src(get_field('image_3','option'),'full');
                    ?>
                    <div class="image" style="background-image: url('{{  $image[0] }}');"></div>
                @endif
            </div>
            <div class="grid-sm-4">
                <div class="content">
                    <h3 class="subtitle">{{ get_field('subtitle_3','option')  }}</h3>
                    <h1 class="title">{{ get_field('title_3','option')  }}</h1>
                    <a class="link" href="{{ get_field('link_3','option') ?: "#"  }}">Läs mer</a>
                </div>
            </div>
        </div>
    </div>
@stop

@section('scroll-btn')
{{-- # Scroll Btn # --}}

    @if(get_field('music_file', 'option') != "")
        <div id="scroll-btn-section">
            <div class="container">
                <a class="btn-bottom" href="#main-content"><i class="fa fa-angle-down" aria-hidden="true"></i></a>
                <audio id="audio" preload="true" loop>
                    <source src="{{ get_field('music_file', 'option')  }}" type="audio/mpeg" />
                    Your browser does not support the audio element.
                </audio>
                <div id="audio-player">
                    <button id="btn-play">
                        <i class="fa fa-play" aria-hidden="true"></i>
                    </button>
                    <button id="btn-mute">
                        <i class="fa fa-volume-up" aria-hidden="true"></i>
                    </button>
                </div>
            </div>
        </div>
    @endif
@stop

@section('content')
@if (is_active_sidebar('content-area'))
<section class="creamy creamy-border-bottom gutter-xl gutter-vertical sidebar-content-area">
    <div class="container">
        <div class="grid">
            <?php dynamic_sidebar('content-area'); ?>
        </div>
    </div>
</section>
@endif

<div class="container">
    <div class="grid">
        <div class="grid-sm-12">
            {!! do_shortcode('[hso-events]') !!}
        </div>
    </div>
</div>


@stop


@section('whatsup-section')
    <div class="container">
        <div id="whatsup">
            <div class="grid">
                <div class="grid-sm-3">
                    {!! do_shortcode('[hso_featured_post]') !!}
                </div>
                <div class="grid-sm-6">
                    {!! do_shortcode('[hso_featured_event]') !!}
                </div>
                <div class="grid-sm-3">
                    {!! do_shortcode('[hso_socialmedia_feed]') !!}
                </div>
            </div>
        </div>
    </div>
@stop
