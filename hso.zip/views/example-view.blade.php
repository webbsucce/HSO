@extends('templates.master')

@section('content')
    <!-- Content start -->
    My content
    <!-- Content end -->
@stop
