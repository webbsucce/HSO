@extends('templates.master')

@section('content')

<div class="single-event">
    <?php
        $header_image_style = "style=background-color:#7492a5";
        // set fatured image
        if(has_post_thumbnail()){
            $image = wp_get_attachment_image_src( get_post_thumbnail_id(), 'full' );
            if($image){
                $header_image_style = "style=background-image:url(".$image[0].")";
            }

        }

        // get title color
        $color = "#000";
        if(get_field('hso_single_event_settings_text_color')){
            $color = get_field('hso_single_event_settings_text_color');
        }

        // get subtitle
        $subtitle = "";
        if(get_field('hso_single_event_settings_subtitle')){
            $subtitle = get_field('hso_single_event_settings_subtitle');
        }

        // get gradient
        $gradient = false;
        if(get_field('hso_single_event_settings_gradient')){
            $gradient = (get_field('hso_single_event_settings_gradient') == "on" ? true : false);
        }
    ?>

    <div id="header-image" {{ $header_image_style }} class="{{ $gradient ? 'shadow' : '' }}">
        <div class="container">
            <div class="grid">
                <div class="grid-sm-12 col">
                    <div class="bottom">
                        <h1 class="title" style="color: {{ $color  }} !important">{{ get_the_title() }}</h1>
                        @if($subtitle)
                            <h3 class="sub-title" style="color: {{ $color  }} !important">{{ $subtitle }}</h3>
                        @endif
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="container main-container">
        @include('partials.breadcrumbs')

        <div class="grid">
            <div class="grid-md-12 grid-lg-8">
                <div class="grid">
                    <div class="grid-sm-12">
                        {!! the_post() !!}
                        @include('partials.blog.type.post-single')
                    </div>
                </div>
            </div>
            <aside class="grid-lg-4 grid-md-12 sidebar-right-sidebar">
                <div class="box">
                    <h4 class="box-title">{{ the_title() }}</h4>
                    <div class="box-content">
                        @if(isset($event_data['transtickets']))
                            <p class="stock"><strong>Stock: </strong> {{ $event_data['transtickets'][0]['stock'] }}</p>
                            @if(isset($event_data['transtickets'][0]['tags']) && !empty($event_data['transtickets'][0]['tags']))
                                <?php
                                    $tags = array();
                                    foreach ($event_data['transtickets'][0]['tags'] as $tag) {
                                        $tags[] = $tag['name'];
                                    }
                                    $tags_string = implode(', ',$tags);
                                ?>
                                <p class="tags"><strong>Tags: </strong>{{ $tags_string }}</p>
                            @endif

                            <h2>Konsertdatum</h2>
                            <ul class="consert-list">
                                @foreach($event_data['transtickets'] as $transticket)
									<li>
										<span>
                                            <i class="fa fa-clock-o" aria-hidden="true"></i>
											<span>{{ date('H.i',strtotime($transticket['releasedate'])) }}</span> TDR <span>{{ date('d M',strtotime($transticket['releasedate'])) }}</span>
										</span>
										<a target="_blank" href="http://helsingborgskonserthus.ebiljett.nu/Home/tickets/{{ $transticket['id'] }}/False">KÖP</a>
										<div class="clear"></div>
									</li>
                                @endforeach
                            </ul>
                        @endif
                    </div>
                </div>
            </aside>
        </div>
    </div>
</div>

@stop
