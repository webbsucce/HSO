var HSOChild = {};

jQuery(document).ready(function($){

	/*
	 * Event isotope
	*/
	var $grid = $('#event-section #items').isotope({
		// options
		itemSelector: '.item',
		layoutMode: 'fitRows'
	});

	// isotope change layout
	$("#event-section .view-selector .layout").on("click",function(){
		var view = $(this).data("layout");

		if(view == "grid-layout"){
			$("#items.grid-layout").css("display","block");
			$("#items.list").css("display","none");
		}else{
			$("#items.grid-layout").css("display","none");
			$("#items.list").css("display","block");
		}

		// Change active item 
		$(this).closest("li").closest("ul").find(".active").removeClass("active");
		$(this).closest("li").addClass("active");

		// regenerate isoteop
		$grid.isotope('destroy');
		$grid = $('#event-section #items').isotope({
			// options
			itemSelector: '.item',
			layoutMode: 'fitRows'
		});
	})

	// filter items on button click
	$('#event-section #filters a').on( 'click', function() {

		// add active class
		$(this).closest("li").closest("ul").find(".active").removeClass("active");
		$(this).closest("li").addClass("active");

		var filterValue = $(this).attr('data-filter');
		if(filterValue)
			$grid.isotope({ filter: "."+filterValue });
		else
			$grid.isotope({ filter: "*" });
	});

	// Handle desktop menu actions
	$("#desktop-menu .btn-close").on("click",function(){
		$("#desktop-menu").fadeOut('slow');
	});

	// Open menu
	$(".quick-menu .btn-menu").on("click",function(){
		$("#desktop-menu").hide().fadeIn('slow')
	});

	var slicknav = $("#desktop-menu .mobile-menu .menu").slicknav({
		duplicate: false,
		label: "",
		appendTo: '#mobile-menu-container'
	});
	slicknav.slicknav('open');

	/**
	 * Handle header search button click
	 */
	$("#header #quick-menu-buttons .btn-search").on("click",function(){
		$("#header #search-bar-container").slideToggle('fast');
	});

	/**
	 * Handle header translate button click
	 */
	$("#header #quick-menu-buttons .btn-translate").on("click",function(){
	});

	/**
	 * Fixed header on scroll show
	*/
	$(window).on("scroll", function() {
		var fromTop = $("body").scrollTop();
		$("#header-fixed").toggleClass("show", (fromTop > $("#header").outerHeight()));

		if((fromTop > $("#header").outerHeight())){
			$("#header-fixed").addClass('animated slideInDown');
		}else{
			$("#header-fixed").removeClass('animated slideInDown');
		}
	});

	/**
	 * Audio player script
	 */
	var audio = $('#audio')[0]; // id for audio element
	var btn_play = $('#btn-play'); // play button
	var btn_mute = $('#btn-mute'); // mute button

	$(btn_play).on("click",function(){
		// start audio
		if (audio.paused) {
			audio.play();
			// remove play, add pause
			$(btn_play).find("i").attr("class","");
			$(btn_play).find("i").addClass("fa").addClass("fa-pause");
		} else { // pause audio
			audio.pause();
			// remove pause, add play
			$(btn_play).find("i").attr("class","");
			$(btn_play).find("i").addClass("fa").addClass("fa-play");
		}
	});

	$(btn_mute).on("click",function(){

		audio.muted = !audio.muted;

		if (audio.muted) {
			$(btn_mute).find("i").attr("class","");
			$(btn_mute).find("i").addClass("fa").addClass("fa-volume-off");
		} else {
			$(btn_mute).find("i").attr("class","");
			$(btn_mute).find("i").addClass("fa").addClass("fa-volume-up");
		}
	});

	// masonary grid
	$('.masonary-grid').masonry({
	  // options
	  itemSelector: '.modularity-mod-text',
	});
});
