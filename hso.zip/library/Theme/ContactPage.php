<?php

namespace HSO\Theme;

class ContactPage
{
    public function __construct()
    {
    	/*add_action( 'after_setup_theme', function(){
    		\Municipio\Helper\Template::add(__('Contact Page', 'hsochild'), \Municipio\Helper\Template::locateTemplate('contact-page.blade.php'));	
    	});*/
        
    }
}
