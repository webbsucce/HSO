<?php

namespace HSO\Theme;

/**
* Class to handle Events shortcode
*/
class ShortcodeEvents
{

	function __construct()
	{

	}	
}
