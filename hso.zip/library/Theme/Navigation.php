<?php
namespace HSO\Theme;

class Navigation
{
    public function __construct()
    {
        $this->registerMenus();
    }

    public function registerMenus()
    {
        $menus = array(
            'full-menu' => __('Full Menu', 'hsochild'),
            'quick-menu' => __('Quick Menu', 'hsochild'),
        );
        register_nav_menus($menus);
    }
}