<?php

namespace HSO\Theme;

class ChefensBloggArchive
{
    public function __construct()
    {
        
    }
}