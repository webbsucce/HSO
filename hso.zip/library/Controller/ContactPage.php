<?php

namespace HSO\Controller;

class ContactPage extends \Municipio\Controller\BaseController
{
    public function init()
    {

    }
}
