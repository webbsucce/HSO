<?php

namespace HSO\Controller;
class SingleChefensBlogg extends \Municipio\Controller\BaseController
{
    public function init()


    }
}
